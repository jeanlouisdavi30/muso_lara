<?php

namespace App\Http\Controllers;

use App\Models\muso;
use App\Models\User;
use App\Models\members;
use Illuminate\Http\Request;
use App\Models\address_musos;
use Illuminate\Validation\Rules;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Hash;
use Illuminate\Auth\Events\Registered;
use App\Providers\RouteServiceProvider;


class MusoController extends Controller
{

    public function index(){
          return view('muso.add_muso');
    }
    
    public function dash(){
        $muso = muso::where('users_id', Auth::user()->id)->first();
        $membre = members::where('musos_id',$muso->id)->get();
        $info_muso = muso::where('id', $muso->id)->first();
        return view('muso.dash', compact('membre','info_muso'));

    }

  
    public function store(Request $request){
        
        $request->validate([
            'nom_muso' => ['required', 'string', 'min:5','max:255'],
            'contry' => ['required', 'string'],
            'phone' => ['required', 'string', 'max:255'],
            'email' => ['required', 'string', 'email', 'max:255', 'unique:users'],
            'password' => ['required', 'confirmed', Rules\Password::defaults()],
        ]);

        $user = User::create([
            'name' => $request->nom_muso,
            'email' => $request->email,
            'password' => Hash::make($request->password),
        ]);
        
        $muso = muso::create([
            'name_muso' => $request->nom_muso,
            'representing' => 'Null',
            'registered_date' => strftime("%Y/%m/%d"),
            'phone' => $request->phone,
            'network' => 'Null',
            'contry' => $request->contry,
            'users_id' =>$user->id,
        ]);

        address_musos::create([
            'address' => 'Null',
            'city' => 'Null',
            'musos_id' => $muso->id,
            'departement' => 'Null',
            'arondisment' =>'Null',
            'pays' => $request->contry,
        ]);


        event(new Registered($user));

        Auth::login($user);

        return redirect(RouteServiceProvider::HOME);
    }


}