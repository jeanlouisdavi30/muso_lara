<?php

namespace App\Http\Controllers;

use App\Models\muso;
use App\Models\members;
use App\Models\settings;
use App\Models\meettings;
use App\Models\rencontre;
use Illuminate\Http\Request;
use App\Models\cotisationCaisse;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Redirect;

class rencontreCtrl extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    function id_muso (){
        $info_user = muso::where('users_id', Auth::user()->id)->get();
        foreach($info_user as $k){
                return $id_muso = $k->id;
        }
    }
    public function index()
    {

        $all_rencontre = meettings::where('musos_id',$this->id_muso())->get();
        return view('muso.rencontre.index', compact('all_rencontre'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'title_meetting' => ['required', 'string', 'min:10','max:255'],
            'date_meetting' => ['required', 'date'],
        ]);


        $membres = members::where('musos_id',$this->id_muso())->get();

        if(!empty($membres)){

            $meettings = meettings::create([
                'title_meetting'=>$request->title_meetting,
                'date_meetting'=>$request->date_meetting,
                'musos_id'=>$this->id_muso(),
            ]);
            
            $montantType = settings::where('musos_id',$this->id_muso())->first();

            if(!empty($request->cr)){

          
                foreach($membres as $key){
                    cotisationCaisse::create([
                        'members_id'=>$key->id,
                        'musos_id'=>$this->id_muso(),
                        'meettings_id'=>$meettings->id,
                        'montant'=>$montantType->cr_cotisation_amount,
                        'type_caisse'=>$request->cr,
                    ]);
                }

            }
            
            if(!empty($request->cv)){
                
                foreach($membres as $key){
                    cotisationCaisse::create([
                        'members_id'=>$key->id,
                        'musos_id'=>$this->id_muso(),
                        'meettings_id'=>$meettings->id,
                        'montant'=>$montantType->cv_cotisation_amount,
                        'type_caisse'=>$request->cv,
                    ]);
                }
            }

            
            return redirect()->back()->with("success"," Rencontre ajouter");

        }else{

            return redirect()->back()->with("error"," Ajouter des membres pouw faire des rencontres");
        }

        
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $all_rencontre = meettings::where('musos_id',$this->id_muso())->get();
        $rencontre = meettings::where('id',$id)->first();
        return view('muso.rencontre.index', compact('all_rencontre','rencontre'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $request->validate([
            'title_meetting' => ['required', 'string', 'min:10','max:255'],
            'date_meetting' => ['required', 'date'],
        ]);
        meettings::where('id', $id)->update([
            'title_meetting' => $request->title_meetting,
            'date_meetting' => $request->date_meetting,
        ]);
        return redirect()->back()->with("success"," Rencontre Update");
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        meettings::where('id',$id)->delete();
        return Redirect::to('rencontre');
    }
}