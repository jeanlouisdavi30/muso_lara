<?php

namespace App\Http\Controllers;

use App\Models\muso;
use App\Models\emprunt;
use App\Models\members;
use App\Models\depenseCR;
use App\Models\partenaire;
use App\Models\autorisation;
use App\Models\fichier_pret;
use Illuminate\Http\Request;
use App\Models\emprunt_apayer;
use App\Models\cotisationCaisse;
use Illuminate\Validation\Rules;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;

class autorisationCtrl extends Controller
{
            
    function id_muso (){
        $info_user = muso::where('users_id', Auth::user()->id)->get();
        foreach($info_user as $k){
                return $id_muso = $k->id;
        }
    }
    
    public function delete(Request $request)
    {

        $validation = Validator::make($request->all(),[
            'password' => ['required']
        ]);

        if($validation->fails()){
            return response()->json(['status'=>0, 'error'=>$validation->errors()]);
        }else{

            $membre = autorisation::where('musos_id',$this->id_muso())->first();
 
                if (Hash::check($request->password,$membre->password)) {
                    if($request->type === 'delete-paiement'){
                        cotisationCaisse::where('id',$request->id)->delete();
                        return response()->json(['status'=>1, 'msg'=>'Paiement supprimer avec succes']);
                    }elseif($request->type === 'delete-depense'){
                        depenseCR::where('id',$request->id)->delete();
                        return response()->json(['status'=>1, 'msg'=>'Depense supprimer avec succes']);
                    }elseif($request->type === 'delete-partenaire'){
                        partenaire::where('id',$request->id)->delete();
                        return response()->json(['status'=>1, 'msg'=>'Partenaire supprimer avec succes']);
                    }elseif($request->type === 'delete-emprunt'){
                        emprunt::where('id',$request->id)->delete();
                        fichier_pret::where('emprunts_id',$request->id)->delete();
                        emprunt_apayer::where('emprunts_id',$request->id)->delete();
                        return response()->json(['status'=>1, 'msg'=>'Emprunt supprimer avec succes']);
                    }
                }else{
                    return response()->json(['status'=>1, 'msg'=>'Mauvais mot de passe']);
                }
              
           
        }

       
    }
}