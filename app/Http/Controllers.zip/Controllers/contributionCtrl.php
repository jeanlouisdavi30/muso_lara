<?php

namespace App\Http\Controllers;

use App\Models\don;
use App\Models\muso;
use App\Models\emprunt;
use App\Models\partenaire;
use App\Models\fichier_don;
use App\Models\autorisation;
use App\Models\fichier_pret;
use Illuminate\Http\Request;
use App\Models\emprunt_apayer;
use App\Models\fichier_rbs;
use App\Models\paiement_emprunt;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;

class contributionCtrl extends Controller
{
    
    function id_muso (){
        $info_user = muso::where('users_id', Auth::user()->id)->first();
        return $info_user->id;
    }
    
    public function index(){
        $all_emprunt  = emprunt::where('musos_id',$this->id_muso())->get();
        $partenaires = partenaire::where('musos_id',$this->id_muso())->get();
        return view('contribution.index', compact('partenaires','all_emprunt'));  
    }

    public function remboursement(){
        $all_emprunt  = emprunt::where('musos_id',$this->id_muso())->get();
        $partenaires = partenaire::where('musos_id',$this->id_muso())->get();
        return view('contribution.remboursement', compact('partenaires','all_emprunt'));  
    }

    public function remboursement_id($id){
            $emprunt_id  = emprunt::select('emprunts.montant','emprunts.description','emprunts.intere_mensuel','emprunts.pmensuel','emprunts.montanttotal',
                'emprunts.ttalmensuel','emprunts.duree','emprunts.pourcentage_interet',
                'emprunts.duree','settings.curency','emprunts.id as id_emprunts','emprunt_apayers.date_paiement')
            ->join('emprunt_apayers', 'emprunt_apayers.emprunts_id', '=', 'emprunts.id')
             ->join('settings', 'settings.musos_id', '=', 'emprunts.musos_id')
             ->where('emprunt_apayers.paiement','false')
            ->where('emprunts.id',$id)
            ->orderByDesc('emprunt_apayers.created_at')->first();
        
                $paiement = emprunt_apayer::where('emprunts_id',$id)->where('paiement','false')->first();

                return view('contribution.remboursement_byId', compact('emprunt_id','paiement'));  
    }
    

    public function voir_pay_emprunt($id){
       
        $don = don::select('don.titre','don.montant','don.date_decaissement','don.numero_cb','don.description','partenaires.name','don.id as id_don')
                    ->join('partenaires','partenaires.id', '=', 'don.partenaire_id')
                  ->join('settings', 'settings.musos_id', '=', 'don.musos_id')
                  ->where('don.id', $id)->first();
        $paiement = emprunt_apayer::select('emprunt_apayers.emprunts_id','settings.curency','emprunt_apayers.paiement','emprunt_apayers.date_paiement','emprunt_apayers.pmensuel','emprunt_apayers.intere_mensuel',
                                            'emprunt_apayers.id as id_emprunt_apayer','emprunt_apayers.ttalmensuel','emprunt_apayers.ttalmensuel')
                                    ->join('settings', 'settings.musos_id', '=', 'emprunt_apayers.musos_id')
                                  ->where('emprunt_apayers.emprunts_id',$id)->get();
        $autorisation = autorisation::join('members', 'members.id', '=', 'autorisations.members_id')->where('autorisations.musos_id', $this->id_muso())->first();
        return view('contribution.index', compact('don','autorisation','paiement'));
    }
    public function voir_don($id){
       
        $don = don::select('don.titre','don.montant','don.date_decaissement','don.numero_cb','don.description','partenaires.name','don.id as id_don')
                    ->join('partenaires','partenaires.id', '=', 'don.partenaire_id')
                  ->join('settings', 'settings.musos_id', '=', 'don.musos_id')
                  ->where('don.id', $id)->first();
        $partenaires = partenaire::where('musos_id',$this->id_muso())->get();
        $fichier = fichier_don::where('don_id',$id)->get();
        $autorisation = autorisation::join('members', 'members.id', '=', 'autorisations.members_id')->where('autorisations.musos_id', $this->id_muso())->first();
        return view('contribution.index', compact('don','partenaires','autorisation','fichier'));
    }

    public function voir_emprunt($id){
       
        $emprunt = emprunt::select('partenaires.name','partenaires.id as id_partenaire','emprunts.titre','emprunts.date_decaissement',
                'emprunts.montant','emprunts.description','emprunts.intere_mensuel','emprunts.pmensuel','emprunts.montanttotal',
                'emprunts.ttalmensuel','emprunts.duree','emprunts.pourcentage_interet','emprunts.duree','settings.curency','emprunts.id as id_emprunts')
                ->join('partenaires','partenaires.id', '=', 'emprunts.partenaire_id')
                ->join('settings', 'settings.musos_id', '=', 'emprunts.musos_id')
                ->where('emprunts.id', $id)->first();

        $fichier = fichier_pret::where('emprunts_id',$id)->get();
        $partenaires = partenaire::where('musos_id',$this->id_muso())->get();
        $autorisation = autorisation::join('members', 'members.id', '=', 'autorisations.members_id')->where('autorisations.musos_id', $this->id_muso())->first();
        return view('contribution.index', compact('emprunt','autorisation','fichier','partenaires'));
    }
    
    public function save_don (Request $request)
    {

            
            $request->validate([
                'partenaire_id' => ['required', 'string'],
                'titre' => ['required', 'string'],
                'montant' => ['required', 'string'],
                'date_decaissement' => ['required', 'string'],
                'numero_cb' => ['string'],
                'description' => ['string'],
            ]);


              $id_don =  don::create([
                'musos_id'=>$this->id_muso(),
                'partenaire_id' => $request->partenaire_id,
                'titre' => $request->titre,
                'montant' => $request->montant,
                'date_decaissement' => $request->date_decaissement,
                'numero_cb' => $request->numero_cb,
                'description' => $request->description,
            ])->id;

            return redirect('voir-don/'.$id_don);

    }

    
    public function save_fichier(Request $request)
    {

        $request->validate([
            'file.*' => 'mimes:png,jpg,jpeg,pdf|max:2048'
        ]);


        if ($request->hasFile('file')) {

            foreach($request->file('file') as $key => $file){
            
                $file->store('all-images', 'public');
                $fichier  = $file->hashName();
                $extension = $file->extension();

                $insert[$key]['fichier'] = $fichier;
                $insert[$key]['type'] = $extension;
                $insert[$key]['don_id'] = $request->id;

            }
            
            fichier_don::insert($insert);

        }

        return redirect()->back()->with("success"," Fichier ajouter");

    }

      public function save_fichier_pret(Request $request)
    {

        $request->validate([
            'file.*' => 'mimes:png,jpg,jpeg,pdf|max:2048'
        ]);


        if ($request->hasFile('file')) {

            foreach($request->file('file') as $key => $file){
            
                $file->store('all-images', 'public');
                $fichier  = $file->hashName();
                $extension = $file->extension();

                $insert[$key]['fichier'] = $fichier;
                $insert[$key]['type'] = $extension;
                $insert[$key]['emprunts_id'] = $request->id;

            }
            
            fichier_pret::insert($insert);

        }

        return redirect()->back()->with("success"," Fichier ajouter");

    }


        public function save_empruts (Request $request)
    {


              $request->validate([
                'partenaire_id' => ['required', 'string'],
                'titre' => ['required', 'string'],
                'date_decaissement'=> ['required', 'string'],
                'montant' => ['required', 'string'],
                'pourcentage_interet' => ['required', 'string'],
                'duree' => ['required', 'string'],
                'pmensuel' =>['required', 'string'],
                'intere_mensuel' =>['required', 'string'],
                'ttalmensuel' => ['required', 'string'],
                'montanttotal' => ['required', 'string'],
            ]);


				$date_echeance = date('Y-m-d', strtotime($request->date_decaissement. ' + '.$request->duree.' months')); 
				$pmensuel = floor($request->pmensuel*100)/100;
				$intere_mensuel = floor($request->intere_mensuel*100)/100;
				$ttalmensuel = floor($request->ttalmensuel*100)/100;
				$montanttotal = floor($request->montanttotal*100)/100;
				
               $id_emprunt = emprunt::create([
                'musos_id'=>$this->id_muso(),
                'partenaire_id' => $request->partenaire_id,
                'titre' => $request->titre,
                'montant' => $request->montant,
                'pourcentage_interet' => $request->pourcentage_interet,
                'duree' => $request->duree,
                'pmensuel' =>$pmensuel,
                 'date_decaissement' => $request->date_decaissement,
                'intere_mensuel' =>$intere_mensuel,
                'ttalmensuel' => $ttalmensuel,
                'montanttotal' =>$montanttotal,
                'frais' => $request->frais,
                'echeance' => $date_echeance,
                'description' => $request->description,

             ])->id;
             $count = 0;

             for($i=0; $request->duree>$i; $i++){
                $count ++;
                $date = date('Y-m-d', strtotime($request->date_decaissement. ' + '.$count.' months')); 
                emprunt_apayer::create([
                    'musos_id'=>$this->id_muso(),
                    'emprunts_id'=>$id_emprunt,
                    'pmensuel' =>$pmensuel ,
                    'intere_mensuel' =>$intere_mensuel,
                    'ttalmensuel' =>$ttalmensuel,
                    'paiement'=>'false',
                    'date_paiement'=>$date
                ]);

             }


            return redirect()->back()->with("success"," Emprunt ajouter");


    }
    



        public function save_remboursement(Request $request)
    {

        $request->validate([
            'file.*' => 'nullable|sometimes|mimes:png,jpg,jpeg,pdf|max:2048',
            'emprunt_apayers_id' =>['required'],
            'date_pay' =>['required'],
            'numeropc' =>['required'],
            'montant' =>['required'],
            'interet_payer' =>['required'],
            'principale_payer' =>['required'],
            'balance_versement' =>['required'],
            'balance_tt_pret' =>['required'],
        ]);

        if($request->date_du_paiement > $request->date_pay){
            $date_pay = "En Avance";
        }elseif($request->date_paiement == $request->date_pay){
                $date_pay = "A l'heure";
        }else{
            $date_pay = "En Retard";
        }

            if($request->balance_versement == '0' ){
				
                $id_p = paiement_emprunt::create([
					'id_emprunt_apayers' => $request->emprunt_apayers_id,
					'date_du_paiement' => $request->date_du_paiement,
                    'date_pay' => $request->date_pay,
					'numeropc' => $request->numeropc,
					'montant' => $request->montant,
					'interet_payer' => $request->interet_payer,
                    'principale_payer' => $request->principale_payer,
                    'balance_versement' => $request->balance_versement,
                    'balance_tt_pret' => $request->balance_tt_pret,
                    'description' => $request->description,
                    'statut' => $date_pay,
				])->id;
				
				emprunt_apayer::where('id', $request->id)->update([
					'paiement' => 'true',
				]);

                if ($request->hasFile('file')) {

                    foreach($request->file('file') as $key => $file){
                    
                        $file->store('all-images', 'public');
                        $fichier  = $file->hashName();
                        $extension = $file->extension();

                        $insert[$key]['fichier'] = $fichier;
                        $insert[$key]['type'] = $extension;
                        $insert[$key]['paiement_emprunts_id'] = $id_p;

                    }
                    
                    fichier_rbs::insert($insert);

                }
                
				    return redirect()->back()->with("success"," Paiment ajouter");

			}elseif($request->balance_versement > 0 ){
				
                $id_p =paiement_emprunt::create([
					'id_emprunt_apayers' => $request->emprunt_apayers_id,
                    'date_du_paiement' => $request->date_du_paiement,
					'date_pay' => $request->date_pay,
					'numeropc' => $request->numeropc,
					'montant' => $request->montant,
					'interet_payer' => $request->interet_payer,
                    'principale_payer' => $request->principale_payer,
                    'balance_versement' => $request->balance_versement,
                    'balance_tt_pret' => $request->balance_tt_pret,
                    'description' => $request->description,
                    'statut' => $date_pay,
				])->id;
				
                if ($request->hasFile('file')) {

                    foreach($request->file('file') as $key => $file){
                    
                        $file->store('all-images', 'public');
                        $fichier  = $file->hashName();
                        $extension = $file->extension();

                        $insert[$key]['fichier'] = $fichier;
                        $insert[$key]['type'] = $extension;
                        $insert[$key]['paiement_emprunts_id'] = $id_p;

                    }
                    
                    fichier_rbs::insert($insert);

                }
				
				return redirect()->back()->with("success"," Paiment ajouter");
				
			}


    }


         public function select_empruts (Request $request)
    {

        $request->validate([
            'emprunt' => ['required', 'string'],
        ]);

        $emprunt_id  = emprunt::join('emprunt_apayers','emprunt_apayers.emprunts_id', '=', 'emprunts.id')
                               ->where('emprunt_apayers.emprunts_id',$request->emprunt)
                               ->where('emprunt_apayers.paiement','false')
                               ->orderByDesc('emprunt_apayers.created_at')->distinct()->limit(1)->get();

        $all_emprunt = emprunt::where('musos_id',$this->id_muso())->get();
        return view('contribution.index', compact('emprunt_id','all_emprunt'));

    }


    public function fiche_emprunt($id){
        $emprunt_id  = emprunt::select('emprunts.titre','emprunts.date_decaissement','emprunts.montant','emprunts.pourcentage_interet',
        'emprunts.duree','emprunts.intere_mensuel','emprunts.ttalmensuel','emprunts.id as id','settings.curency','emprunts.montanttotal')
        ->join('settings', 'settings.musos_id', '=', 'emprunts.musos_id')->where('emprunts.id',$id)->first();
        return view('contribution.fiche_emprunt', compact('emprunt_id'));  
    }
    
}