<?php

namespace App\Http\Controllers;

use DateTime;
use App\Models\muso;
use App\Models\depenseCR;
use Illuminate\Http\Request;
use App\Models\cotisationCaisse;
use App\Models\fichierDepense;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;


class retraitcrCtrl extends Controller
{
    public function index(){

        return view('caisseRouge.retrait');
        
    }

    public function voir_depense($id){

        $depenses = depenseCR::where('id', $id)->first();
        $fichier = fichierDepense::where('depensecr_id', $id)->get();
        return view('caisseRouge.retrait',compact('depenses','fichier'));
        
    }

    

        public function save_retrait(Request $request)
    {
         $muso = muso::where('users_id', Auth::user()->id)->first();

       $validation = Validator::make($request->all(),[
            'file.*' => 'mimes:png,jpg,jpeg,pdf|max:2048',
            'description' => ['required', 'string', 'min:10','max:255'],
            'date' => ['required', 'date'],
            'montant' => ['required', 'string'],
            'type' => ['required', 'string'],
            'beneficiare' => ['required', 'string'],
            'autre_detail' => ['required', 'string'],
        ]);

        if($validation->fails()){
            return response()->json(['status'=>0, 'error'=>$validation->errors()]);
        }else{

            $caisse = cotisationCaisse::where('musos_id',$muso->id)
                ->where('type_caisse','caisse-rouge')
                ->where('pay','true')
                ->sum('montant');

            $depnse_all = depenseCR::where('musos_id',$muso->id)->sum('montant');

            $somme = $caisse - $depnse_all;
                             
          if($somme > $request->montant){

                $id_depense  = depenseCR::create([
                    'musos_id' => $muso->id,
                    'description' => $request->description,
                    'date' => $request->date,
                    'montant' => $request->montant,
                    'type' => $request->type,
                    'beneficiare' => $request->beneficiare,
                    'autre_detail' => $request->autre_detail,
                ])->id;

                    if ($request->hasFile('file')) {

                        foreach($request->file('file') as $key => $file)
                        {
                            $file->store('all-images', 'public');
                            $fichier  = $file->hashName();
                            $extension = $file->extension();

                             $insert[$key]['fichier'] = $fichier;
                             $insert[$key]['type'] = $extension;
                             $insert[$key]['depensecr_id'] = $id_depense;

   
                        }

                        fichierDepense::insert($insert);

                    }
                    return response()->json(['status'=>1, 'msg'=>'Depense Ajouter']);

          }else{
                 return response()->json(['status'=>1, 'msg'=>'Error vous navez pas assez dargent dans la caisse rouge']);

          }

        }

    }



       public function eddit_depense(Request $request)
    {
         $muso = muso::where('users_id', Auth::user()->id)->first();

        $validation = Validator::make($request->all(),[
            'description' => ['required', 'string', 'min:10','max:255'],
            'date' => ['required', 'date'],
            'montant' => ['required', 'string'],
            'type' => ['required', 'string'],
            'beneficiare' => ['required', 'string'],
            'autre_detail' => ['required', 'string'],
        ]);

          if($validation->fails()){
            return response()->json(['status'=>0, 'error'=>$validation->errors()]);
        }else{
          depenseCR::where('id', $request->id)->update([
            'musos_id' => $muso->id,
            'description' => $request->description,
            'date' => $request->date,
            'montant' => $request->montant,
            'type' => $request->type,
            'beneficiare' => $request->beneficiare,
            'autre_detail' => $request->autre_detail,
        ]);
         return response()->json(['status'=>1, 'msg'=>'Depense modifier avec succès']);
    }

    }


    public function rapport_depense(Request $request){
        $muso = muso::where('users_id', Auth::user()->id)->first();
        $request->validate([
            'd1' => ['required', 'date'],
            'd2' => ['required', 'date'],
        ]);

        $d1 = new DateTime($request->d1);
        $d2 = new DateTime($request->d2);

        $rapport = depenseCR::join('settings', 'settings.musos_id', '=', 'depensecr.musos_id')
                    ->where('depensecr.musos_id', $muso->id)
                    ->where('depensecr.date','>=', $d1->format('Y-m-d'))
                    ->where('depensecr.date','<=', $d2->format('Y-m-d'))->get();
                    
        $somme = depenseCR::where('depensecr.musos_id', $muso->id)
                    ->where('depensecr.date','>=', $d1->format('Y-m-d'))
                    ->where('depensecr.musos_id', $muso->id)
                    ->where('depensecr.date','<=', $d2->format('Y-m-d'))->sum('montant');        
                       return view('caisseRouge.retrait',compact('rapport', 'somme'));

    }

    
    
}