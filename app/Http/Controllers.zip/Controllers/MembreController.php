<?php

namespace App\Http\Controllers;

use App\Models\muso;
use App\Models\User;
use App\Models\membre;
use App\Models\members;
use Illuminate\Http\Request;
use Illuminate\Validation\Rules;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;

class MembreController extends Controller
{
    public function ajouter(){
        return view('membre.ajouter');
    }
    
    public function lister(){
        $info_user = muso::where('users_id', Auth::user()->id)->first();
        $membre = members::where('musos_id',$info_user->id)->get();
        return view('membre.lister',compact('membre'));
    }

       public function store(Request $request){
        
        $info_user = muso::where('users_id', Auth::user()->id)->get();
        foreach($info_user as $k){
               $id_muso = $k->id;
        }
          $request->validate([
            'nom' => ['required', 'string', 'max:255'],
            'prenom' => ['required', 'string', 'max:255'],
            'sexe' => ['required', 'string', 'max:255'],
            'date_naissance' => ['required', 'date'],
            'phone' => ['required', 'string', 'max:255'],
            'type_of_id' => ['required', 'string', 'max:255'],
            'id_number' => ['required', 'string', 'max:255'],
            'function' => ['required', 'string', 'max:55'],
            'adresse' => ['required', 'string', 'max:255'],
            'email' => ['required', 'string', 'email', 'max:255', 'unique:users'],
            'password' => ['required', Rules\Password::defaults()],
        ]);

 
            
            $user = User::create([
                'name' => $request->nom." ".$request->prenom,
                'email' => $request->email,
                'utype' => "membre",
                'password' => Hash::make($request->password),
            ]);
            
            members::create([
                
                'last_name' => $request->nom,
                'first_name' => $request->prenom,
                'sexe' => $request->sexe,
                'email' => $request->email,
                'musos_id' =>$id_muso,

                'date_birth' => $request->date_naissance,
                'type_of_id' => $request->type_of_id,
                'id_number' => $request->id_number,
                'phone' =>$request->phone,
                'function' =>$request->function,
                'matrimonial_state' =>$request->matrimonial_state,

                'picture'=>'picture.png',
                'users_id' =>$user->id,
            ]);
            
            return redirect()->back()->with("success","membre ajouter");

     


    }

    public function md_pass_membre(Request $request){

        $request->validate([
           'password' => ['required', Rules\Password::defaults()],
        ]);
        
        $members = members::where('id', $request->id)->first();        
        User::where('id', $members->users_id)->update([
           'password' => Hash::make($request->password),
        ]);
        return redirect()->back()->with("success_password","Password update");

    }

        public function update(Request $request){
        

        $request->validate([
            'nom' => ['required', 'string', 'max:255'],
            'prenom' => ['required', 'string', 'max:255'],
            'date_birth' => ['required', 'string', 'max:255'],
            'sexe' => ['required', 'string', 'max:255'],
            'phone' => ['required', 'string', 'max:255'],
            'type_of_id' => ['required', 'string', 'max:255'],
            'id_number' => ['required', 'string', 'max:255'],
            'matrimonial_state' => ['required', 'string', 'max:255'],
            'function' => ['required', 'string', 'max:255'],
            'email' => ['required', 'string', 'email', 'max:255'],
        ]);
        
        
        members::where('id', $request->id)->update([
            'last_name' => $request->nom,
            'first_name' => $request->prenom,
            'date_birth' => $request->date_birth,
            'sexe' => $request->sexe,
            'email' => $request->email,
            'phone' => $request->phone,
            'type_of_id' => $request->type_of_id,
            'id_number' => $request->id_number,
            'matrimonial_state' => $request->matrimonial_state,
            'function' => $request->function,
        ]);
        return redirect()->back()->with("success","membre update");

    }

    public function update_member($id){
        $membre = members::where('id',$id)->first();
        return view('membre.update-member',compact('membre'));
    }

    public function member_info($id){
        $membre = members::where('id',$id)->first();
        return view('membre.member-info',compact('membre'));
    }

    public function delete_member($id){
        
        members::where('id',$id)->delete();
        $info_user = muso::where('users_id', Auth::user()->id)->get();
        foreach($info_user as $k){
               $id_muso = $k->id;
        }
        $membre = members::where('musos_id',$id_muso)->get();
        return view('membre.lister',compact('membre'));
    }

    public function upload_photo_m(Request $request){
        
        $request->validate([
            'file' => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:20000',
        ]);

        if ($request->hasFile('file')) {

            // Save the file locally in the storage/public/ folder under a new folder named /product
			$request->file->store('all-images', 'public');

        }

        members::where('id', $request->id)->update([
            'picture'=>$request->file->hashName(),
        ]);
        return redirect()->back()->with("success","Photo update");
    }
}