<?php

namespace App\Http\Controllers;

use App\Models\muso;
use App\Models\members;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class dashboarCtrl extends Controller
{
    public function index (){
        if(Auth::user()->utype == "admin"){
            $info_muso = muso::where('users_id',Auth::user()->id)->first();
            return view('muso.dash',compact('info_muso'));
        }else{
            $membre = members::where('users_id',Auth::user()->id)->first();
            return view('dash.membre',compact('membre'));
        }
        
    }
}